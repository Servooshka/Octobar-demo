OCTOBAR - PRESS KIT
===================

Website: https://octobar.dev
Press kit page: https://octobar.dev/press.html

DESCRIPTION
Octobar is an octopus bartender game set in an alternative 1920s, where you serve
drinks to monstrous patrons. It is a puzzle-strategy mashup: plan your movements
before you act, and keep an eye on each guest's patience.

KEY FACTS
Developer:  Octobar team
Platform:   Windows
Engine:     Godot
Genre:      Simulation, Strategy
Price:      Free
Status:     In development since February 2026
Players:    Singleplayer
Download:   https://download.octobar.dev/Octobar.exe
Game page:  https://servooshka.itch.io/octobar

TEAM
Sarver Salakhutdinov (Servoo) - Programmer
Dominica Vishnevskaya (Zomino) - Art, idea and game design
Vera Eremeeva (Fayenowo) - Art and game design

CONTACT
servoo@octobar.dev

FILES IN THIS ZIP
octobar-logo.png   Cream wordmark logo (transparent background)
octobar-icon.png   Octobar icon (512x512)
screenshot-1.jpg   Game screenshot, full size
screenshot-2.jpg   Game screenshot, full size
screenshot-3.jpg   Game screenshot, full size
screenshot-4.jpg   Game screenshot, full size
README.txt         This file
